<?php
header('location: ../eduarda_g/public/inicio.php');

