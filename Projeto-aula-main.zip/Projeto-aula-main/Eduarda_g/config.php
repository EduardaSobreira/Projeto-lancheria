<?php

define('MYSQL_SERVER',       'localhost');
define('MYSQL_DATABASE',     'lancheria');
define('MYSQL_USER',         'root');
define('MYSQL_PASS',           '');
define('MYSQL_CHARSET',      'utf8');
