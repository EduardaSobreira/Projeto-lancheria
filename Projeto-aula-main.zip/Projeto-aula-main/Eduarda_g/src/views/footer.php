<footer>
    Nenhum direito reservado - <?= date("Y") ?>
</footer>

</body>
</html>